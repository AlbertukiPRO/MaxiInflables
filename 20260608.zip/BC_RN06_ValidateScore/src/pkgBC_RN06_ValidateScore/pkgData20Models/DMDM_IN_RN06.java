package pkgBC_RN06_ValidateScore.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN06_ValidateScore",DataModelName="DM_IN_RN06",EventTypeName="") public class DMDM_IN_RN06 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Double slotscoreINE;
  private Double slotscoreSelfie;
  @IDataAnnotation(OriginalFieldName="scoreINE",FieldName="slotscoreINE",SlotKey="/scoreINE;3.4;0",Position=0,CameFromFloat=false) public Double getSlotscoreINE(){
    return this.slotscoreINE;
  }
  @IDataAnnotation(OriginalFieldName="scoreINE",FieldName="slotscoreINE",SlotKey="/scoreINE;3.4;0",Position=0,CameFromFloat=false) public void setSlotscoreINE(  Double paramscoreINE){
    this.slotscoreINE=paramscoreINE;
  }
  @IDataAnnotation(OriginalFieldName="scoreINE",FieldName="slotscoreINE",SlotKey="/scoreINE;3.4;0",Position=0,CameFromFloat=false) public void setSlotscoreINE(  String paramscoreINE){
    if (paramscoreINE != null) {
      this.slotscoreINE=Double.valueOf(paramscoreINE);
    }
 else {
      this.slotscoreINE=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="scoreINE",FieldName="slotscoreINE",SlotKey="/scoreINE;3.4;0",Position=0,CameFromFloat=false) public void setSlotscoreINE(  Long paramscoreINE){
    if (paramscoreINE != null) {
      this.slotscoreINE=Double.valueOf(paramscoreINE);
    }
 else {
      this.slotscoreINE=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="scoreSelfie",FieldName="slotscoreSelfie",SlotKey="/scoreSelfie;3.4;0",Position=1,CameFromFloat=false) public Double getSlotscoreSelfie(){
    return this.slotscoreSelfie;
  }
  @IDataAnnotation(OriginalFieldName="scoreSelfie",FieldName="slotscoreSelfie",SlotKey="/scoreSelfie;3.4;0",Position=1,CameFromFloat=false) public void setSlotscoreSelfie(  Double paramscoreSelfie){
    this.slotscoreSelfie=paramscoreSelfie;
  }
  @IDataAnnotation(OriginalFieldName="scoreSelfie",FieldName="slotscoreSelfie",SlotKey="/scoreSelfie;3.4;0",Position=1,CameFromFloat=false) public void setSlotscoreSelfie(  String paramscoreSelfie){
    if (paramscoreSelfie != null) {
      this.slotscoreSelfie=Double.valueOf(paramscoreSelfie);
    }
 else {
      this.slotscoreSelfie=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="scoreSelfie",FieldName="slotscoreSelfie",SlotKey="/scoreSelfie;3.4;0",Position=1,CameFromFloat=false) public void setSlotscoreSelfie(  Long paramscoreSelfie){
    if (paramscoreSelfie != null) {
      this.slotscoreSelfie=Double.valueOf(paramscoreSelfie);
    }
 else {
      this.slotscoreSelfie=null;
    }
  }
}
