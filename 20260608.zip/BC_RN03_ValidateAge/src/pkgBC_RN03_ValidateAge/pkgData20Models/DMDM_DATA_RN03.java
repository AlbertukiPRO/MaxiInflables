package pkgBC_RN03_ValidateAge.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN03_ValidateAge",DataModelName="DM_DATA_RN03",EventTypeName="") public class DMDM_DATA_RN03 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Integer slotAGE;
  private Integer slotAGE_MIN;
  private Integer slotAGE_MAX;
  private Boolean slotReturn;
  private String slotIdReason;
  @IDataAnnotation(OriginalFieldName="AGE",FieldName="slotAGE",SlotKey="/AGE;3.6;0",Position=0,CameFromFloat=false) public Integer getSlotAGE(){
    return this.slotAGE;
  }
  @IDataAnnotation(OriginalFieldName="AGE",FieldName="slotAGE",SlotKey="/AGE;3.6;0",Position=0,CameFromFloat=false) public void setSlotAGE(  Integer paramAGE){
    this.slotAGE=paramAGE;
  }
  @IDataAnnotation(OriginalFieldName="AGE",FieldName="slotAGE",SlotKey="/AGE;3.6;0",Position=0,CameFromFloat=false) public void setSlotAGE(  String paramAGE){
    if (paramAGE != null) {
      this.slotAGE=Integer.valueOf(paramAGE);
    }
 else {
      this.slotAGE=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="AGE",FieldName="slotAGE",SlotKey="/AGE;3.6;0",Position=0,CameFromFloat=false) public void setSlotAGE(  Double paramAGE){
    if (paramAGE != null) {
      this.slotAGE=paramAGE.intValue();
    }
 else {
      this.slotAGE=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="AGE_MIN",FieldName="slotAGE_MIN",SlotKey="/AGE_MIN;3.6;0",Position=1,CameFromFloat=false) public Integer getSlotAGE_MIN(){
    return this.slotAGE_MIN;
  }
  @IDataAnnotation(OriginalFieldName="AGE_MIN",FieldName="slotAGE_MIN",SlotKey="/AGE_MIN;3.6;0",Position=1,CameFromFloat=false) public void setSlotAGE_MIN(  Integer paramAGE_MIN){
    this.slotAGE_MIN=paramAGE_MIN;
  }
  @IDataAnnotation(OriginalFieldName="AGE_MIN",FieldName="slotAGE_MIN",SlotKey="/AGE_MIN;3.6;0",Position=1,CameFromFloat=false) public void setSlotAGE_MIN(  String paramAGE_MIN){
    if (paramAGE_MIN != null) {
      this.slotAGE_MIN=Integer.valueOf(paramAGE_MIN);
    }
 else {
      this.slotAGE_MIN=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="AGE_MIN",FieldName="slotAGE_MIN",SlotKey="/AGE_MIN;3.6;0",Position=1,CameFromFloat=false) public void setSlotAGE_MIN(  Double paramAGE_MIN){
    if (paramAGE_MIN != null) {
      this.slotAGE_MIN=paramAGE_MIN.intValue();
    }
 else {
      this.slotAGE_MIN=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="AGE_MAX",FieldName="slotAGE_MAX",SlotKey="/AGE_MAX;3.6;0",Position=2,CameFromFloat=false) public Integer getSlotAGE_MAX(){
    return this.slotAGE_MAX;
  }
  @IDataAnnotation(OriginalFieldName="AGE_MAX",FieldName="slotAGE_MAX",SlotKey="/AGE_MAX;3.6;0",Position=2,CameFromFloat=false) public void setSlotAGE_MAX(  Integer paramAGE_MAX){
    this.slotAGE_MAX=paramAGE_MAX;
  }
  @IDataAnnotation(OriginalFieldName="AGE_MAX",FieldName="slotAGE_MAX",SlotKey="/AGE_MAX;3.6;0",Position=2,CameFromFloat=false) public void setSlotAGE_MAX(  String paramAGE_MAX){
    if (paramAGE_MAX != null) {
      this.slotAGE_MAX=Integer.valueOf(paramAGE_MAX);
    }
 else {
      this.slotAGE_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="AGE_MAX",FieldName="slotAGE_MAX",SlotKey="/AGE_MAX;3.6;0",Position=2,CameFromFloat=false) public void setSlotAGE_MAX(  Double paramAGE_MAX){
    if (paramAGE_MAX != null) {
      this.slotAGE_MAX=paramAGE_MAX.intValue();
    }
 else {
      this.slotAGE_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=3,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=3,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
  @IDataAnnotation(OriginalFieldName="IdReason",FieldName="slotIdReason",SlotKey="/IdReason;1;0",Position=4,CameFromFloat=false) public String getSlotIdReason(){
    return this.slotIdReason;
  }
  @IDataAnnotation(OriginalFieldName="IdReason",FieldName="slotIdReason",SlotKey="/IdReason;1;0",Position=4,CameFromFloat=false) public void setSlotIdReason(  String paramIdReason){
    this.slotIdReason=paramIdReason;
  }
}
