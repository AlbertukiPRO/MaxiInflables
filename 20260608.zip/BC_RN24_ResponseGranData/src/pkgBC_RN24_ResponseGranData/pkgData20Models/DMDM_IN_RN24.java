package pkgBC_RN24_ResponseGranData.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN24_ResponseGranData",DataModelName="DM_IN_RN24",EventTypeName="") public class DMDM_IN_RN24 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotcode;
  @IDataAnnotation(OriginalFieldName="code",FieldName="slotcode",SlotKey="/code;1;0",Position=0,CameFromFloat=false) public String getSlotcode(){
    return this.slotcode;
  }
  @IDataAnnotation(OriginalFieldName="code",FieldName="slotcode",SlotKey="/code;1;0",Position=0,CameFromFloat=false) public void setSlotcode(  String paramcode){
    this.slotcode=paramcode;
  }
}
