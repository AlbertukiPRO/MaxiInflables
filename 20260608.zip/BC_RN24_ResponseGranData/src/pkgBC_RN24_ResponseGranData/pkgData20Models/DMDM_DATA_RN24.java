package pkgBC_RN24_ResponseGranData.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN24_ResponseGranData",DataModelName="DM_DATA_RN24",EventTypeName="") public class DMDM_DATA_RN24 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Boolean slotReturn;
  private String slotResponse;
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=0,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=0,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
  @IDataAnnotation(OriginalFieldName="Response",FieldName="slotResponse",SlotKey="/Response;1;0",Position=1,CameFromFloat=false) public String getSlotResponse(){
    return this.slotResponse;
  }
  @IDataAnnotation(OriginalFieldName="Response",FieldName="slotResponse",SlotKey="/Response;1;0",Position=1,CameFromFloat=false) public void setSlotResponse(  String paramResponse){
    this.slotResponse=paramResponse;
  }
}
