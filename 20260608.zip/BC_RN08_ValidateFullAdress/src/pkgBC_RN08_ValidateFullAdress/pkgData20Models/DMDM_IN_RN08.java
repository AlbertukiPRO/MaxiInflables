package pkgBC_RN08_ValidateFullAdress.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN08_ValidateFullAdress",DataModelName="DM_IN_RN08",EventTypeName="") public class DMDM_IN_RN08 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotcp;
  private String slotstate;
  private String slotcity;
  private String slotcolony;
  private String slotstreet;
  @IDataAnnotation(OriginalFieldName="cp",FieldName="slotcp",SlotKey="/cp;1;0",Position=0,CameFromFloat=false) public String getSlotcp(){
    return this.slotcp;
  }
  @IDataAnnotation(OriginalFieldName="cp",FieldName="slotcp",SlotKey="/cp;1;0",Position=0,CameFromFloat=false) public void setSlotcp(  String paramcp){
    this.slotcp=paramcp;
  }
  @IDataAnnotation(OriginalFieldName="state",FieldName="slotstate",SlotKey="/state;1;0",Position=1,CameFromFloat=false) public String getSlotstate(){
    return this.slotstate;
  }
  @IDataAnnotation(OriginalFieldName="state",FieldName="slotstate",SlotKey="/state;1;0",Position=1,CameFromFloat=false) public void setSlotstate(  String paramstate){
    this.slotstate=paramstate;
  }
  @IDataAnnotation(OriginalFieldName="city",FieldName="slotcity",SlotKey="/city;1;0",Position=2,CameFromFloat=false) public String getSlotcity(){
    return this.slotcity;
  }
  @IDataAnnotation(OriginalFieldName="city",FieldName="slotcity",SlotKey="/city;1;0",Position=2,CameFromFloat=false) public void setSlotcity(  String paramcity){
    this.slotcity=paramcity;
  }
  @IDataAnnotation(OriginalFieldName="colony",FieldName="slotcolony",SlotKey="/colony;1;0",Position=3,CameFromFloat=false) public String getSlotcolony(){
    return this.slotcolony;
  }
  @IDataAnnotation(OriginalFieldName="colony",FieldName="slotcolony",SlotKey="/colony;1;0",Position=3,CameFromFloat=false) public void setSlotcolony(  String paramcolony){
    this.slotcolony=paramcolony;
  }
  @IDataAnnotation(OriginalFieldName="street",FieldName="slotstreet",SlotKey="/street;1;0",Position=4,CameFromFloat=false) public String getSlotstreet(){
    return this.slotstreet;
  }
  @IDataAnnotation(OriginalFieldName="street",FieldName="slotstreet",SlotKey="/street;1;0",Position=4,CameFromFloat=false) public void setSlotstreet(  String paramstreet){
    this.slotstreet=paramstreet;
  }
}
