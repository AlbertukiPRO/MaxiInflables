package pkgBC_RN18_ConsultParametricRule.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN18_ConsultParametricRule",DataModelName="DM_DATA_RN18",EventTypeName="") public class DMDM_DATA_RN18 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Integer slotElement;
  private Integer slotSection;
  private Integer slotGroup;
  @IDataAnnotation(OriginalFieldName="Element",FieldName="slotElement",SlotKey="/Element;3.6;0",Position=0,CameFromFloat=false) public Integer getSlotElement(){
    return this.slotElement;
  }
  @IDataAnnotation(OriginalFieldName="Element",FieldName="slotElement",SlotKey="/Element;3.6;0",Position=0,CameFromFloat=false) public void setSlotElement(  Integer paramElement){
    this.slotElement=paramElement;
  }
  @IDataAnnotation(OriginalFieldName="Element",FieldName="slotElement",SlotKey="/Element;3.6;0",Position=0,CameFromFloat=false) public void setSlotElement(  String paramElement){
    if (paramElement != null) {
      this.slotElement=Integer.valueOf(paramElement);
    }
 else {
      this.slotElement=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Element",FieldName="slotElement",SlotKey="/Element;3.6;0",Position=0,CameFromFloat=false) public void setSlotElement(  Double paramElement){
    if (paramElement != null) {
      this.slotElement=paramElement.intValue();
    }
 else {
      this.slotElement=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Section",FieldName="slotSection",SlotKey="/Section;3.6;0",Position=1,CameFromFloat=false) public Integer getSlotSection(){
    return this.slotSection;
  }
  @IDataAnnotation(OriginalFieldName="Section",FieldName="slotSection",SlotKey="/Section;3.6;0",Position=1,CameFromFloat=false) public void setSlotSection(  Integer paramSection){
    this.slotSection=paramSection;
  }
  @IDataAnnotation(OriginalFieldName="Section",FieldName="slotSection",SlotKey="/Section;3.6;0",Position=1,CameFromFloat=false) public void setSlotSection(  String paramSection){
    if (paramSection != null) {
      this.slotSection=Integer.valueOf(paramSection);
    }
 else {
      this.slotSection=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Section",FieldName="slotSection",SlotKey="/Section;3.6;0",Position=1,CameFromFloat=false) public void setSlotSection(  Double paramSection){
    if (paramSection != null) {
      this.slotSection=paramSection.intValue();
    }
 else {
      this.slotSection=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Group",FieldName="slotGroup",SlotKey="/Group;3.6;0",Position=2,CameFromFloat=false) public Integer getSlotGroup(){
    return this.slotGroup;
  }
  @IDataAnnotation(OriginalFieldName="Group",FieldName="slotGroup",SlotKey="/Group;3.6;0",Position=2,CameFromFloat=false) public void setSlotGroup(  Integer paramGroup){
    this.slotGroup=paramGroup;
  }
  @IDataAnnotation(OriginalFieldName="Group",FieldName="slotGroup",SlotKey="/Group;3.6;0",Position=2,CameFromFloat=false) public void setSlotGroup(  String paramGroup){
    if (paramGroup != null) {
      this.slotGroup=Integer.valueOf(paramGroup);
    }
 else {
      this.slotGroup=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Group",FieldName="slotGroup",SlotKey="/Group;3.6;0",Position=2,CameFromFloat=false) public void setSlotGroup(  Double paramGroup){
    if (paramGroup != null) {
      this.slotGroup=paramGroup.intValue();
    }
 else {
      this.slotGroup=null;
    }
  }
}
