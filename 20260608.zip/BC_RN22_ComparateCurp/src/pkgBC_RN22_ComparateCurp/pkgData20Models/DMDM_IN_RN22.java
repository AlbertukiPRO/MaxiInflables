package pkgBC_RN22_ComparateCurp.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN22_ComparateCurp",DataModelName="DM_IN_RN22",EventTypeName="") public class DMDM_IN_RN22 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotcurpINE;
  private String slotcurpRENAPO;
  @IDataAnnotation(OriginalFieldName="curpINE",FieldName="slotcurpINE",SlotKey="/curpINE;1;0",Position=0,CameFromFloat=false) public String getSlotcurpINE(){
    return this.slotcurpINE;
  }
  @IDataAnnotation(OriginalFieldName="curpINE",FieldName="slotcurpINE",SlotKey="/curpINE;1;0",Position=0,CameFromFloat=false) public void setSlotcurpINE(  String paramcurpINE){
    this.slotcurpINE=paramcurpINE;
  }
  @IDataAnnotation(OriginalFieldName="curpRENAPO",FieldName="slotcurpRENAPO",SlotKey="/curpRENAPO;1;0",Position=1,CameFromFloat=false) public String getSlotcurpRENAPO(){
    return this.slotcurpRENAPO;
  }
  @IDataAnnotation(OriginalFieldName="curpRENAPO",FieldName="slotcurpRENAPO",SlotKey="/curpRENAPO;1;0",Position=1,CameFromFloat=false) public void setSlotcurpRENAPO(  String paramcurpRENAPO){
    this.slotcurpRENAPO=paramcurpRENAPO;
  }
}
