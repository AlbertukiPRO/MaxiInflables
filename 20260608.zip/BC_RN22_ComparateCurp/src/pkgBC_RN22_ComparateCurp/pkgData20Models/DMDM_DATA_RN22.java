package pkgBC_RN22_ComparateCurp.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN22_ComparateCurp",DataModelName="DM_DATA_RN22",EventTypeName="") public class DMDM_DATA_RN22 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Boolean slotReturn;
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=0,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=0,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
}
