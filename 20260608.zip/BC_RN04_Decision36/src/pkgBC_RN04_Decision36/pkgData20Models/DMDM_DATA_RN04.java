package pkgBC_RN04_Decision36.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN04_Decision36",DataModelName="DM_DATA_RN04",EventTypeName="") public class DMDM_DATA_RN04 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Boolean slotReturn;
  private String slotRejectionReason;
  private String slotCode;
  private String slotCause;
  private String slotSpecialSituation;
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=0,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=0,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
  @IDataAnnotation(OriginalFieldName="RejectionReason",FieldName="slotRejectionReason",SlotKey="/RejectionReason;1;0",Position=1,CameFromFloat=false) public String getSlotRejectionReason(){
    return this.slotRejectionReason;
  }
  @IDataAnnotation(OriginalFieldName="RejectionReason",FieldName="slotRejectionReason",SlotKey="/RejectionReason;1;0",Position=1,CameFromFloat=false) public void setSlotRejectionReason(  String paramRejectionReason){
    this.slotRejectionReason=paramRejectionReason;
  }
  @IDataAnnotation(OriginalFieldName="Code",FieldName="slotCode",SlotKey="/Code;1;0",Position=2,CameFromFloat=false) public String getSlotCode(){
    return this.slotCode;
  }
  @IDataAnnotation(OriginalFieldName="Code",FieldName="slotCode",SlotKey="/Code;1;0",Position=2,CameFromFloat=false) public void setSlotCode(  String paramCode){
    this.slotCode=paramCode;
  }
  @IDataAnnotation(OriginalFieldName="Cause",FieldName="slotCause",SlotKey="/Cause;1;0",Position=3,CameFromFloat=false) public String getSlotCause(){
    return this.slotCause;
  }
  @IDataAnnotation(OriginalFieldName="Cause",FieldName="slotCause",SlotKey="/Cause;1;0",Position=3,CameFromFloat=false) public void setSlotCause(  String paramCause){
    this.slotCause=paramCause;
  }
  @IDataAnnotation(OriginalFieldName="SpecialSituation",FieldName="slotSpecialSituation",SlotKey="/SpecialSituation;1;0",Position=4,CameFromFloat=false) public String getSlotSpecialSituation(){
    return this.slotSpecialSituation;
  }
  @IDataAnnotation(OriginalFieldName="SpecialSituation",FieldName="slotSpecialSituation",SlotKey="/SpecialSituation;1;0",Position=4,CameFromFloat=false) public void setSlotSpecialSituation(  String paramSpecialSituation){
    this.slotSpecialSituation=paramSpecialSituation;
  }
}
