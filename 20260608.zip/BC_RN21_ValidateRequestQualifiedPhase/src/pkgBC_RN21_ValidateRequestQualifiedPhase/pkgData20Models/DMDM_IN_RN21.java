package pkgBC_RN21_ValidateRequestQualifiedPhase.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN21_ValidateRequestQualifiedPhase",DataModelName="DM_IN_RN21",EventTypeName="") public class DMDM_IN_RN21 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotphase;
  @IDataAnnotation(OriginalFieldName="phase",FieldName="slotphase",SlotKey="/phase;1;0",Position=0,CameFromFloat=false) public String getSlotphase(){
    return this.slotphase;
  }
  @IDataAnnotation(OriginalFieldName="phase",FieldName="slotphase",SlotKey="/phase;1;0",Position=0,CameFromFloat=false) public void setSlotphase(  String paramphase){
    this.slotphase=paramphase;
  }
}
