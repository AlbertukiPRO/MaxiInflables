package pkgBC_RN12_ValidateScoreMeeting.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN12_ValidateScoreMeeting",DataModelName="DM_IN_RN12",EventTypeName="") public class DMDM_IN_RN12 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Double slotscore;
  @IDataAnnotation(OriginalFieldName="score",FieldName="slotscore",SlotKey="/score;3.4;0",Position=0,CameFromFloat=false) public Double getSlotscore(){
    return this.slotscore;
  }
  @IDataAnnotation(OriginalFieldName="score",FieldName="slotscore",SlotKey="/score;3.4;0",Position=0,CameFromFloat=false) public void setSlotscore(  Double paramscore){
    this.slotscore=paramscore;
  }
  @IDataAnnotation(OriginalFieldName="score",FieldName="slotscore",SlotKey="/score;3.4;0",Position=0,CameFromFloat=false) public void setSlotscore(  String paramscore){
    if (paramscore != null) {
      this.slotscore=Double.valueOf(paramscore);
    }
 else {
      this.slotscore=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="score",FieldName="slotscore",SlotKey="/score;3.4;0",Position=0,CameFromFloat=false) public void setSlotscore(  Long paramscore){
    if (paramscore != null) {
      this.slotscore=Double.valueOf(paramscore);
    }
 else {
      this.slotscore=null;
    }
  }
}
