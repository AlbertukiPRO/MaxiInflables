package pkgBC_RN12_ValidateScoreMeeting.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN12_ValidateScoreMeeting",DataModelName="DM_DATA_RN12",EventTypeName="") public class DMDM_DATA_RN12 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Double slotscorePermitted;
  private Boolean slotReturn;
  @IDataAnnotation(OriginalFieldName="scorePermitted",FieldName="slotscorePermitted",SlotKey="/scorePermitted;3.4;0",Position=0,CameFromFloat=false) public Double getSlotscorePermitted(){
    return this.slotscorePermitted;
  }
  @IDataAnnotation(OriginalFieldName="scorePermitted",FieldName="slotscorePermitted",SlotKey="/scorePermitted;3.4;0",Position=0,CameFromFloat=false) public void setSlotscorePermitted(  Double paramscorePermitted){
    this.slotscorePermitted=paramscorePermitted;
  }
  @IDataAnnotation(OriginalFieldName="scorePermitted",FieldName="slotscorePermitted",SlotKey="/scorePermitted;3.4;0",Position=0,CameFromFloat=false) public void setSlotscorePermitted(  String paramscorePermitted){
    if (paramscorePermitted != null) {
      this.slotscorePermitted=Double.valueOf(paramscorePermitted);
    }
 else {
      this.slotscorePermitted=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="scorePermitted",FieldName="slotscorePermitted",SlotKey="/scorePermitted;3.4;0",Position=0,CameFromFloat=false) public void setSlotscorePermitted(  Long paramscorePermitted){
    if (paramscorePermitted != null) {
      this.slotscorePermitted=Double.valueOf(paramscorePermitted);
    }
 else {
      this.slotscorePermitted=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
}
