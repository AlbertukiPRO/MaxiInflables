package pkgBC_RN23_ValidateActiveRequest_V2.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN23_ValidateActiveRequest_V2",DataModelName="DM_IN_RN23",EventTypeName="") public class DMDM_IN_RN23 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotstatus;
  private String slotchannel;
  @IDataAnnotation(OriginalFieldName="status",FieldName="slotstatus",SlotKey="/status;1;0",Position=0,CameFromFloat=false) public String getSlotstatus(){
    return this.slotstatus;
  }
  @IDataAnnotation(OriginalFieldName="status",FieldName="slotstatus",SlotKey="/status;1;0",Position=0,CameFromFloat=false) public void setSlotstatus(  String paramstatus){
    this.slotstatus=paramstatus;
  }
  @IDataAnnotation(OriginalFieldName="channel",FieldName="slotchannel",SlotKey="/channel;1;0",Position=1,CameFromFloat=false) public String getSlotchannel(){
    return this.slotchannel;
  }
  @IDataAnnotation(OriginalFieldName="channel",FieldName="slotchannel",SlotKey="/channel;1;0",Position=1,CameFromFloat=false) public void setSlotchannel(  String paramchannel){
    this.slotchannel=paramchannel;
  }
}
