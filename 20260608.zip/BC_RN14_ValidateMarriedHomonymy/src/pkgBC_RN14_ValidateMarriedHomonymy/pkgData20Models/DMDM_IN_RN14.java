package pkgBC_RN14_ValidateMarriedHomonymy.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN14_ValidateMarriedHomonymy",DataModelName="DM_IN_RN14",EventTypeName="") public class DMDM_IN_RN14 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotmaritalStatus;
  @IDataAnnotation(OriginalFieldName="maritalStatus",FieldName="slotmaritalStatus",SlotKey="/maritalStatus;1;0",Position=0,CameFromFloat=false) public String getSlotmaritalStatus(){
    return this.slotmaritalStatus;
  }
  @IDataAnnotation(OriginalFieldName="maritalStatus",FieldName="slotmaritalStatus",SlotKey="/maritalStatus;1;0",Position=0,CameFromFloat=false) public void setSlotmaritalStatus(  String parammaritalStatus){
    this.slotmaritalStatus=parammaritalStatus;
  }
}
