package pkgBC_RN26_ValidateTelcosDate.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN26_ValidateTelcosDate",DataModelName="DM_DATA_RN26",EventTypeName="") public class DMDM_DATA_RN26 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private Long slotDAYS_MAX;
  private Boolean slotReturn;
  @IDataAnnotation(OriginalFieldName="DAYS_MAX",FieldName="slotDAYS_MAX",SlotKey="/DAYS_MAX;3.7;0",Position=0,CameFromFloat=false) public Long getSlotDAYS_MAX(){
    return this.slotDAYS_MAX;
  }
  @IDataAnnotation(OriginalFieldName="DAYS_MAX",FieldName="slotDAYS_MAX",SlotKey="/DAYS_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotDAYS_MAX(  Long paramDAYS_MAX){
    this.slotDAYS_MAX=paramDAYS_MAX;
  }
  @IDataAnnotation(OriginalFieldName="DAYS_MAX",FieldName="slotDAYS_MAX",SlotKey="/DAYS_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotDAYS_MAX(  String paramDAYS_MAX){
    if (paramDAYS_MAX != null) {
      this.slotDAYS_MAX=Long.valueOf(paramDAYS_MAX);
    }
 else {
      this.slotDAYS_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="DAYS_MAX",FieldName="slotDAYS_MAX",SlotKey="/DAYS_MAX;3.7;0",Position=0,CameFromFloat=false) public void setSlotDAYS_MAX(  Double paramDAYS_MAX){
    if (paramDAYS_MAX != null) {
      this.slotDAYS_MAX=paramDAYS_MAX.longValue();
    }
 else {
      this.slotDAYS_MAX=null;
    }
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public Boolean getSlotReturn(){
    return this.slotReturn;
  }
  @IDataAnnotation(OriginalFieldName="Return",FieldName="slotReturn",SlotKey="/Return;3.1;0",Position=1,CameFromFloat=false) public void setSlotReturn(  Boolean paramReturn){
    this.slotReturn=paramReturn;
  }
}
