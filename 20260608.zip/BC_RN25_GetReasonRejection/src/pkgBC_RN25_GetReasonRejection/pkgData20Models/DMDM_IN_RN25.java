package pkgBC_RN25_GetReasonRejection.pkgData20Models;
import com.softwareag.rules.datamodel.IRuleAnnotation;
import com.softwareag.rules.datamodel.AbstractBaseDataModel;
import com.softwareag.rules.datamodel.IDataAnnotation;
@IRuleAnnotation(RuleProjectName="BC_RN25_GetReasonRejection",DataModelName="DM_IN_RN25",EventTypeName="") public class DMDM_IN_RN25 extends AbstractBaseDataModel {
  private static final long serialVersionUID=1L;
  private String slotid;
  @IDataAnnotation(OriginalFieldName="id",FieldName="slotid",SlotKey="/id;1;0",Position=0,CameFromFloat=false) public String getSlotid(){
    return this.slotid;
  }
  @IDataAnnotation(OriginalFieldName="id",FieldName="slotid",SlotKey="/id;1;0",Position=0,CameFromFloat=false) public void setSlotid(  String paramid){
    this.slotid=paramid;
  }
}
